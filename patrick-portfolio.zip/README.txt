A Pen created at CodePen.io. You can find this one at http://codepen.io/ScootMcBoot/pen/akWAqq.

 My personal portfolio.